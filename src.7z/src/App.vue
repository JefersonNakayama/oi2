<template>
  <div id="app">
    <nav>
      <router-link to="/cadastro">Cadastro</router-link>
      <router-link to="/listagem">Listagem</router-link>
      <router-link to="/delecao">Deleção</router-link>
    </nav>
    <router-view />
  </div>
</template>

<script>
export default {
  name: "App",
};
</script>

<style>
nav {
  display: flex;
  gap: 10px;
  margin-bottom: 20px;
}
</style>
